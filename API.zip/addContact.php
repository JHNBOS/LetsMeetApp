<?php 
 
	//Getting values
	$name = $_GET['name'];
	$email = $_GET['email'];
	
	//Importing our db connection script
	require_once('dbConnect.php');
	
	if(!strpos($email,'@') === true|| !strpos($email,'.') === true){
		echo 'Please enter a valid email address!';
	} else {
	//Check if exists
	$sql = "SELECT * FROM contacts WHERE email='$email' AND name='$name'";
	$create = "INSERT INTO contacts (contact_email, email) VALUES ('$name', '$email')";
	$check = mysqli_query($con,$sql);
	
	if($email == "" || $name == ""){
		echo 'Please fill in all fields';
	} else{
	
		if(!$row = mysql_fetch_array($check)){
			$data = mysqli_query($con,$create);
		
			if($data){
				echo "$name";
			} else{
				echo 'Contact is already added!';
			}
		} else {
			echo 'Unable to find and/or add contact. Please try again!';
		}
	}
	
	
	//Closing the database 
	mysqli_close($con);
	}
	
 