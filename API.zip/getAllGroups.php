<?php 
	 //Importing Database Script 
	 require_once('dbConnect.php');
	 
	 //Getting values
	 $email = $_GET['email'];
	 
	 //Creating sql query
	 $sql = "SELECT * FROM groups LEFT JOIN groupmembers ON groups.name = groupmembers.group_name WHERE groupmembers.email = $email;";
	 
	 //getting result 
	 $r = mysqli_query($con,$sql);
	 
	 //creating a blank array 
	 $result = array();
	 
	 //looping through all the records fetched
	 while($row = mysqli_fetch_array($r)){
	 
	 //Pushing name and id in the blank array created 
	 array_push($result,array(
		"id"=>$row['id'],
		"name"=>$row['name'],
		"creator"=>$row['creator']
		 ));
	 }
	 
	 //Displaying the array in json format 
	 echo json_encode(array($result));
	 
	 mysqli_close($con);