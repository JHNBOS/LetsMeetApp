<?php 
	 //Getting values 
	 $name = $_POST['name'];
	 $email = $_POST['email'];

	 
	 //importing database connection script 
	 require_once('dbConnect.php');
	 
	 //Creating sql query 
	 $sql = "UPDATE groups SET email = $email WHERE name = $name;";
	 
	 //Updating database table 
	 if(mysqli_query($con,$sql)){
	 	echo '$email';
	 }else if($email == ""){
	 	echo "Email not defined!";
	 }else{
	 	echo "Unable to update group. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);
	 