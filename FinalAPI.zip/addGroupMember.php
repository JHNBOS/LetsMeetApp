<?php 
 
	//Getting values
	$name = $_GET['name'];
	$email = $_GET['email'];
	
	//Importing our db connection script
	require_once('dbConnect.php');
	
	
	//Check if exists
	$sql = "SELECT * FROM groupmembers WHERE email = $email AND name = $name;";
	$create = "INSERT INTO groupmembers (group_name, email) VALUES ('$name', '$email');";
	$check = mysqli_query($con,$sql);
	
	if($email == "" || $name == ""){
		echo "Please select someone to add as groupmember";
	} else{
	
		if(!$row = mysql_fetch_array($check)){
			$data = mysqli_query($con,$create);
		
			if($data){
				echo "$name";
			} else{
				echo "Groupmember is already added!";
			}
		} else {
			echo "Unable to find and/or add groupmember. Please try again!";
		}
	}
	
	
	//Closing the database 
	mysqli_close($con);
 
 