<?php 
 
 //Getting the requested id
 $name = $_GET['name'];
 
 //Importing Database Script 
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "SELECT * FROM user LEFT JOIN groupmembers ON user.email = groupmembers.email WHERE groupmembers.group_name = $name";
 
 //getting result 
 $r = mysqli_query($con,$sql);
 
 //creating a blank array 
 $result = array();
 
 //looping through all the records fetched
 while($row = mysqli_fetch_array($r)){
 
 //Pushing name and id in the blank array created 
array_push($result,array(
"id"=>$row['id'],
"first_name"=>$row['first_name'],
"last_name"=>$row['last_name'],
"color"=>$row['color'],
"email"=>$row['email'],
"password"=>$row['password']

 ));
 }
 
 //Displaying the array in json format 
 header('Content-Type: application/json');
 echo json_encode(array($result));
 
 mysqli_close($con);