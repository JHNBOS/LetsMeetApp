<?php 
 
	 //Getting values
	 $title = $_POST['title'];
	 $loc = $_POST['loc'];
	 $start = $_POST['start'];
	 $ends = $_POST['end'];
	 $creator = $_POST['creator'];
	 $group = $_POST['group'];
	 $color = $_POST['color'];
	 
	 //Creating an sql query
	 $sql = "INSERT INTO event (title, location, start, end, creator, group_name, color) VALUES ('$title','$loc','$start', '$ends', '$creator', '$group', '$color');";
	 
	 //Importing our db connection script
	 require_once('dbConnect.php');
	 
	 //Executing query to database
	 if(mysqli_query($con,$sql)){
	 	echo "$title";
	 }else if($title == "" || $creator == ""){
	 	echo "Please fill in all fields!";
	 }else{
	 	echo "Unable to add event. Please try again!";
	 }
	 
	 //Closing the database 
	 mysqli_close($con);
 