<?php
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$preturn = $email . $password;

	require_once('dbConnect.php');

	$sql = "select * from user where email = $email and password = $password";

	$check = mysqli_fetch_array(mysqli_query($con,$sql));

	if(isset($check)){
		echo "$preturn";
	} else if($email == "" || $password == ""){
		echo "Please fill in all fields!";
	}else{
		echo "Invalid username and/or password!";
	}
	
	mysqli_close($con);
