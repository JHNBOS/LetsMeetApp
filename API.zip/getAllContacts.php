<?php 
 
 //Getting the requested id
 $email= $_GET['email'];
 
 //Importing Database Script 
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "SELECT u.id, u.first_name, u.last_name, u.email, u.color FROM user u LEFT JOIN contacts c ON u.email = c.contact_email WHERE c.email = $email";
 
 //getting result 
 $r = mysqli_query($con,$sql);
 
 //creating a blank array 
 $result = array();
 
 //looping through all the records fetched
 while($row = mysqli_fetch_array($r)){
 
 //Pushing name and id in the blank array created 
array_push($result,array(
"id"=>$row['id'],
"first_name"=>$row['first_name'],
"last_name"=>$row['last_name'],
"color"=>$row['color'],
"email"=>$row['email'],

 ));
 }
 
 //Displaying the array in json format 
 header('Content-Type: application/json');
 echo json_encode(array($result));
 
 mysqli_close($con);