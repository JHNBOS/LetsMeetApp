<?php 
 
	 //Getting the requested id
	 $name = $_GET['name'];
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query with where clause to get an specific employee
	 $sql = "SELECT * FROM groups WHERE name='$name'";
	 
	 //getting result 
	 $r = mysqli_query($con,$sql);
	 
	 //pushing result to an array 
	 $result = array();
	 $row = mysqli_fetch_array($r);
	 array_push($result,array(
		"id"=>$row['id'],
		"name"=>$row['name'],
		"creator"=>$row['creator']
	 ));
	 
	 //displaying in json format 
	 echo json_encode(array($result));
	 
	 mysqli_close($con);