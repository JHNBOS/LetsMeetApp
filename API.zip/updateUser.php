<?php 
	 //Getting values 
	 $fname = $_POST['first_name'];
	 $lname = $_POST['last_name'];
	 $email = $_POST['email'];
	 $pass = $_POST['password'];
	 $color = $_POST['color'];
	 $id = $_POST['id'];
	 
	 //importing database connection script 
	 require_once('dbConnect.php');
	 
	 //Creating sql query 
	 $sql = "UPDATE user SET first_name = $fname, last_name = $lname, email= $email, password = $pass, color = $color WHERE id = $id;";
	 
	 //Updating database table 
	 if(mysqli_query($con,$sql)){
	 	echo '$email';
	 }else if($email == ""){
	 	echo "Email not defined!";
	 }else{
	 	echo "Unable to update user. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);
	 