<?php 
	 //Importing Database Script 
	 require_once('dbConnect.php');
	 
	 //Getting values
	 $email = $_GET['email'];
	 
	 //Creating sql query
	 $sql = "SELECT c.id, c.contact_email, c.email
		FROM contacts c
		LEFT OUTER JOIN groupmembers g ON c.contact_email = g.email
		WHERE g.email IS NULL
		AND c.email = '$email'
		AND g.group_name IS NULL;";
	 
	 //getting result 
	 $r = mysqli_query($con,$sql);
	 
	 //creating a blank array 
	 $result = array();
	 
	 //looping through all the records fetched
	 while($row = mysqli_fetch_array($r)){
	 
	 //Pushing name and id in the blank array created 
	 array_push($result,array(
		"id"=>$row['id'],
		"contact_email"=>$row['contact_email'],
		"email"=>$row['email']
		 ));
	 }
	 
	 //Displaying the array in json format 
	 echo json_encode(array($result));
	 
	 mysqli_close($con);