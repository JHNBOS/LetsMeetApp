<?php 
	 //Importing Database Script 
	 require_once('dbConnect.php');
	 
	 //Getting values
	 $group = $_GET['group'];
	 
	 //Creating sql query
	 $sql = "SELECT * FROM event WHERE group_name = $group;";
	 
	 //getting result 
	 $r = mysqli_query($con,$sql);
	 
	 //creating a blank array 
	 $result = array();
	 
	 //looping through all the records fetched
	 while($row = mysqli_fetch_array($r)){
	 
	 //Pushing name and id in the blank array created 
	 array_push($result,array(
		"id"=>$row['id'],
		"title"=>$row['title'],
		"location"=>$row['location'],
		"start"=>$row['start'],
		"end"=>$row['end'],
		"creator"=>$row['creator'],
		"group_name"=>$row['group_name'],
		"color"=>$row['color']
		
		 ));
	 }
	 
	 //Displaying the array in json format 
	echo json_encode(array($result)).
	 
	 mysqli_close($con);