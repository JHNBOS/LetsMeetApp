<?php 
	 //Getting Id
	 $name = $_GET['name'];
	 $email = $_GET['email'];
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query
	 $sql = "DELETE FROM contacts WHERE contact_email = $name AND email = $email;";
	 
	 //Deleting record in database 
	 if(mysqli_query($con,$sql)){
	 	echo "Successfully removed contact!";
	 }else{
	 	echo "Unable to remove contact. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);