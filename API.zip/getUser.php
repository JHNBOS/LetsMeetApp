<?php 
 
	 //Getting the requested id
	 $email = $_GET['email'];
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query with where clause to get an specific employee
	 $sql = "SELECT * FROM user WHERE email = $email;";
	  
	 //getting result 
	 $r = mysqli_query($con,$sql);
	 
	 //pushing result to an array 
	 $result = array();
	 $row = mysqli_fetch_array($r);
	 array_push($result,array(
		"id"=>$row['id'],
		"first_name"=>$row['first_name'],
		"last_name"=>$row['last_name'],
		"email"=>$row['email'],
		"password"=>$row['password'],
		"color"=>$row['color']
	 ));
	 
	 //displaying in json format 
	 echo json_encode(array($result));
	 
	 mysqli_close($con);