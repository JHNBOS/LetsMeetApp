<?php 
 
	//Getting values
	$name = $_GET['name'];
	$email = $_GET['email'];
	
	//Importing our db connection script
	require_once('dbConnect.php');
	
	if(!strpos($email,'@') === true|| !strpos($email,'.') === true){
		echo "Please enter a valid email address!";
	} else {
	
	$sql = "SELECT * FROM user WHERE email='$email' AND name='$name'";
	$sql2 = "SELECT * FROM contacts WHERE email=$email AND contact_emai=$name";
	$create = "INSERT INTO contacts (contact_email, email) VALUES ('$name', '$email')";
	
	$check = mysqli_query($con,$sql);
	$check2 = mysqli_query($con,$sql2);


	if($email == "" || $name == ""){
		echo  "Please fill in all fields";
	} else{
	
		if(!$row = mysql_fetch_array($check)){
			if(!$row = mysql_fetch_array($check2){
				$data = mysqli_query($con,$create);
		
				if($data){
					echo "$name";
				} else{
					echo "Contact is already added!";
				}
			
			} else {
				echo "Contact already added!";
			}			
		} else {
			echo "User doesn't exist. Please try again!";
		}
	}
	
	
	//Closing the database 
	mysqli_close($con);
	}
	
 