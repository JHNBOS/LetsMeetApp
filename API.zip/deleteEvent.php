<?php 
	 //Getting Id
	 $title = $_GET['title'];
	
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query
	 $sql = "DELETE FROM event WHERE title=$title;";
	 
	 //Deleting record in database 
	 if(mysqli_query($con,$sql)){
	 	echo '$title';
	 }else{
	 	echo "Unable to delete event. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);