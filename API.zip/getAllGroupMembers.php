<?php 
 
 //Getting the requested id
 $name = $_GET['name'];
 
 //Importing Database Script 
 require_once('dbConnect.php');
 
 //Creating sql query
 $sql = "SELECT * FROM groupmembers WHERE group_name=$name";
 
 //getting result 
 $r = mysqli_query($con,$sql);
 
 //creating a blank array 
 $result = array();
 
 //looping through all the records fetched
 while($row = mysqli_fetch_array($r)){
 
 //Pushing name and id in the blank array created 
 array_push($result,array(
"id"=>$row['id'],
"group_name"=>$row['group_name'],
"email"=>$row['email']

 ));
 }
 
 //Displaying the array in json format 
 header('Content-Type: application/json');
 echo json_encode(array($result));
 
 mysqli_close($con);