<?php 
	 //Getting Id
	 $group = $_GET['group_name'];
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query
	 $sql = "DELETE FROM event WHERE group_name='$group'";
	 
	 //Deleting record in database 
	 if(mysqli_query($con,$sql)){
	 	echo "$group";
	 }else{
	 	echo "Unable to delete events. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);