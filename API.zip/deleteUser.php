<?php 
	 //Getting Id
	 $email = $_GET['email'];
	 
	 //Importing database
	 require_once('dbConnect.php');
	 
	 //Creating sql query
	 $sql = "DELETE FROM user WHERE email = $email;";
	 
	 //Deleting record in database 
	 if(mysqli_query($con,$sql)){
	 	echo "$email";
	 }else{
	 	echo "Unable to delete user. Please try again!";
	 }
	 
	 //closing connection 
	 mysqli_close($con);